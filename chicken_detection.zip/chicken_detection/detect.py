import time
import numpy as np
import cv2
import torch
import torch.backends.cudnn as cudnn
from models.experimental import attempt_load
from utils.general import non_max_suppression
from torchvision import models
import random
import math
from torchvision import transforms
import time
import requests


yolov5_weight_file = 'chicken.pt' 
conf_set = 0.30 

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = attempt_load(yolov5_weight_file, map_location=device)
cudnn.benchmark = True 
names = model.module.names if hasattr(model, 'module') else model.names



def object_detection(frame):
    img = torch.from_numpy(frame)
    img = img.permute(2, 0, 1 ).float().to(device)
    img /= 255.0  
    if img.ndimension() == 3:
        img = img.unsqueeze(0)

    pred = model(img, augment=False)[0]
    pred = non_max_suppression(pred, conf_set, 0.45) # prediction, conf, iou

    detection_result = []
    for i, det in enumerate(pred):
        if len(det): 
            for d in det: # d = (x1, y1, x2, y2, conf, cls)
                x1 = int(d[0].item())
                y1 = int(d[1].item())
                x2 = int(d[2].item())
                y2 = int(d[3].item())
                conf = round(d[4].item(), 2)
                c = int(d[5].item())
                
                detected_name = names[c]
                detection_result.append([x1, y1, x2, y2, conf, c])
                
                ## Bounding box
                frame = cv2.rectangle(frame, (x1, y1), (x2, y2), (255,0,0), 2) # box
                frame = cv2.putText(frame, f'{names[c]} {str(conf)}', (x1, y1), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,0,255), 2, cv2.LINE_AA)
    return (frame, detection_result)


