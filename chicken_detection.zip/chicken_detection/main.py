import asyncio
import logging
import logging.handlers
import queue
import threading
import urllib.request
from pathlib import Path
from typing import List, NamedTuple

try:
    from typing import Literal
except ImportError:
    from typing_extensions import Literal  # type: ignore

import av
import cv2
import matplotlib.pyplot as plt
import numpy as np
import pydub
import streamlit as st
from aiortc.contrib.media import MediaPlayer

from streamlit_webrtc import (
    AudioProcessorBase,
    ClientSettings,
    VideoProcessorBase,
    WebRtcMode,
    webrtc_streamer,
)

import detect # custom python file



HERE = Path(__file__).parent

logger = logging.getLogger(__name__)

WEBRTC_CLIENT_SETTINGS = ClientSettings(
    rtc_configuration={"iceServers": [{"urls": ["stun:stun.l.google.com:19302"]}]},
    media_stream_constraints={"video": True, "audio": True},
)

st.title('Object detection demo')



def main():
    class OpenCVVideoProcessor(VideoProcessorBase):


        def recv(self, frame: av.VideoFrame) -> av.VideoFrame:
            frame = frame.to_ndarray(format="bgr24")
            frame = cv2.resize(frame, (352, 288))
            frame, results = detect.object_detection(frame) 
            print(results)

            return av.VideoFrame.from_ndarray(frame, format="bgr24")

    webrtc_ctx = webrtc_streamer(
        key="object_detection",
        mode=WebRtcMode.SENDRECV,
        client_settings=WEBRTC_CLIENT_SETTINGS,
        video_processor_factory=OpenCVVideoProcessor,
        async_processing=True,
    )

    # if webrtc_ctx.video_processor:
    #     webrtc_ctx.video_processor.type = st.radio(
    #         "Select transform type", ("noop", "cartoon", "edges", "rotate")
    #     )


main()