# With pip:
#pip install facenet-pytorch

# or clone this repo, removing the '-' to allow python imports:
#git clone https://github.com/timesler/facenet-pytorch.git facenet_pytorch



# importing libraries

from facenet_pytorch import MTCNN, InceptionResnetV1
import torch
from torchvision import datasets
from torch.utils.data import DataLoader
from PIL import Image
import cv2
import time
import os
import telepot 



def notify_telegram(name, photo):
    token = '1234560:GHJGxJN9ee5vsmF35VjM8_Jg3nIKJHGHFG' # telegram token
    receiver_id = 123456789 # https://api.telegram.org/bot<TOKEN>/getUpdates  
    bot = telepot.Bot(token)
    bot.sendMessage(receiver_id, f'{name} detected on camera.') # send a message on telegram
    bot.sendPhoto(receiver_id, photo=open(photo, 'rb')) # send photo as well


# initializing MTCNN and InceptionResnetV1
mtcnn0 = MTCNN(image_size=144, margin=0, keep_all=False, min_face_size=40) # keep_all=False
mtcnn = MTCNN(image_size=144, margin=0, keep_all=True, min_face_size=40) # keep_all=True
resnet = InceptionResnetV1(pretrained='vggface2').eval()

# Read data from folder
dataset = datasets.ImageFolder('photos') # photos folder path
idx_to_class = {i:c for c,i in dataset.class_to_idx.items()}

def collate_fn(x):
    return x[0]


loader = DataLoader(dataset, collate_fn=collate_fn)


name_list = [] # list of names corrospoing to cropped photos
embedding_list = [] # list of embeding matrix after conversion from cropped faces to embedding matrix using resnet

for img, idx in loader:
    face, prob = mtcnn0(img, return_prob=True) 
    if face is not None and prob>0.92:
        emb = resnet(face.unsqueeze(0)) 
        embedding_list.append(emb.detach()) 
        name_list.append(idx_to_class[idx]) 


# capture using cv2
cam = cv2.VideoCapture(0)

while True:
    ret, frame = cam.read()
    if not ret:
        print("fail to grab frame, try again")
        break
        
    img = Image.fromarray(frame)
    img_cropped_list, prob_list = mtcnn(img, return_prob=True) 
    
    if img_cropped_list is not None:
        boxes, _ = mtcnn.detect(img)
                
        for i, prob in enumerate(prob_list):
            if prob>0.90:
                emb = resnet(img_cropped_list[i].unsqueeze(0)).detach() 
                
                dist_list = [] # list of matched distances, minimum distance is used to identify the person
                
                for idx, emb_db in enumerate(embedding_list):
                    dist = torch.dist(emb, emb_db).item()
                    dist_list.append(dist)

                min_dist = min(dist_list) # get minumum dist value
                min_dist_idx = dist_list.index(min_dist) # get minumum dist index
                name = name_list[min_dist_idx] # get name corrosponding to minimum dist
                
                box = boxes[i] 
                
                original_frame = frame.copy() # storing copy of frame before drawing on it
                
                frame = cv2.rectangle(frame, (box[0],box[1]) , (box[2],box[3]), (255,0,0), 2)
                
                if min_dist<0.90:
                    print(f'{name} detected.')
                    frame = cv2.putText(frame, name, (box[0],box[1]), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,0),1, cv2.LINE_AA)
                    photo_path = 'temp_face.png'
                    cv2.imwrite(photo_path, frame) 
                    notify_telegram(name, photo_path)

                

    cv2.imshow("IMG", frame) # comment this line, if don't want to display result.
        
    
    k = cv2.waitKey(1)
    if k%256==27: # ESC
        print('Esc pressed, closing...')
        break
        
        
cam.release()
cv2.destroyAllWindows()

